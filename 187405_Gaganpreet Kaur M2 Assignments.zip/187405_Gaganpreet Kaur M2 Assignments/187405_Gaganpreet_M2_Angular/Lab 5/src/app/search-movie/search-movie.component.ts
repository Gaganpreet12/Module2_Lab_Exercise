import { Component, OnInit } from '@angular/core';
import {MovieService} from '../movie.service';
import { Movies } from '../movies';
@Component({
  selector: 'app-search-movie',
  templateUrl: './search-movie.component.html',
  styleUrls: ['./search-movie.component.css']
})
export class SearchMovieComponent implements OnInit {
 
  genre:String[]=["Drama","Fiction","Satire"];
  moviesbyGenre:Array<Movies>;
  constructor(private service:MovieService) { }

  ngOnInit() {
  }
  searchMovie(data)
  {
    this.moviesbyGenre=this.service.searchMovie(data.genre);
  }

}
