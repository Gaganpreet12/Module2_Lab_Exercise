import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './main.html',
  //styleUrls: ['./app.component.css']

})
export class AppComponent {
  title:string = 'Welcome to Angular5............';
  welcome:string = 'Capgemini';
}
